# Colonel Fried Chicken POS

Aplikasi POS Android offline berbasis Flutter + SQLite/Room-equivalent (sqflite).

## Fitur
- Katalog Satuan, Paket, Add-on
- Keranjang dan qty
- Total otomatis
- Tunai dan QRIS
- Hitung kembalian
- Simpan transaksi lokal
- Laporan harian
- Produk terlaris
- Cetak/simpan struk PDF melalui Android Print/Share
- Offline-first

## Catatan
Harga awal di `lib/data/app_database.dart` sengaja diberi contoh dan dapat diubah di sana.

## Menjalankan
```bash
flutter pub get
flutter analyze
flutter run
```

## Build APK
```bash
flutter build apk --release
```
Hasil umum:
`build/app/outputs/flutter-apk/app-release.apk`

Untuk APK per arsitektur:
```bash
flutter build apk --release --split-per-abi
```

## Struktur
- `lib/main.dart` - entry point
- `lib/models/` - model data
- `lib/data/` - SQLite
- `lib/services/` - PDF/struk
- `lib/screens/` - UI kasir & laporan
- `lib/widgets/` - komponen UI
