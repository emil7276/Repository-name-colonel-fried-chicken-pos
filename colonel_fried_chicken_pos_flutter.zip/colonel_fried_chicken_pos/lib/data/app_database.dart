import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/product.dart';

class AppDatabase {
  AppDatabase._();
  static final instance = AppDatabase._();
  Database? _db;

  Future<Database> get db async {
    if (_db != null) return _db!;
    _db = await _open();
    return _db!;
  }

  Future<Database> _open() async {
    final path = join(await getDatabasesPath(), 'colonel_fried_chicken.db');
    return openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''
        CREATE TABLE products(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          category TEXT NOT NULL,
          price INTEGER NOT NULL,
          active INTEGER NOT NULL DEFAULT 1
        )
      ''');
      await db.execute('''
        CREATE TABLE transactions(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          invoice_no TEXT NOT NULL,
          created_at TEXT NOT NULL,
          payment_method TEXT NOT NULL,
          subtotal INTEGER NOT NULL,
          paid INTEGER NOT NULL,
          change_amount INTEGER NOT NULL
        )
      ''');
      await db.execute('''
        CREATE TABLE transaction_items(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          transaction_id INTEGER NOT NULL,
          product_id INTEGER NOT NULL,
          product_name TEXT NOT NULL,
          qty INTEGER NOT NULL,
          price INTEGER NOT NULL,
          subtotal INTEGER NOT NULL
        )
      ''');
      await _seed(db);
    });
  }

  Future<void> _seed(Database db) async {
    final products = <List<Object>>[
      ['Dada', 'Satuan', 12000],
      ['Paha Atas', 'Satuan', 12000],
      ['Paha Bawah', 'Satuan', 11000],
      ['Sayap', 'Satuan', 9000],
      ['Paket 1: Nasi + Sayap', 'Paket', 15000],
      ['Paket 2: Nasi + Paha Bawah', 'Paket', 17000],
      ['Paket 3: Nasi + Paha Atas', 'Paket', 18000],
      ['Paket 4: Nasi + Dada', 'Paket', 18000],
      ['Sambal Geprek', 'Add-on', 3000],
      ['Kentang Goreng', 'Add-on', 8000],
      ['Air Mineral', 'Add-on', 4000],
      ['Es Teh', 'Add-on', 4000],
    ];
    for (final p in products) {
      await db.insert('products', {
        'name': p[0],
        'category': p[1],
        'price': p[2],
        'active': 1,
      });
    }
  }

  Future<List<Product>> products(String category) async {
    final d = await db;
    final rows = await d.query(
      'products',
      where: 'category = ? AND active = 1',
      whereArgs: [category],
      orderBy: 'id ASC',
    );
    return rows.map(Product.fromMap).toList();
  }

  Future<int> saveTransaction({
    required String invoiceNo,
    required DateTime createdAt,
    required String paymentMethod,
    required int subtotal,
    required int paid,
    required int changeAmount,
    required List<Map<String, Object>> items,
  }) async {
    final d = await db;
    return d.transaction((txn) async {
      final id = await txn.insert('transactions', {
        'invoice_no': invoiceNo,
        'created_at': createdAt.toIso8601String(),
        'payment_method': paymentMethod,
        'subtotal': subtotal,
        'paid': paid,
        'change_amount': changeAmount,
      });
      for (final item in items) {
        await txn.insert('transaction_items', {
          'transaction_id': id,
          ...item,
        });
      }
      return id;
    });
  }

  Future<Map<String, Object>> dailySummary(DateTime day) async {
    final d = await db;
    final start = DateTime(day.year, day.month, day.day);
    final end = start.add(const Duration(days: 1));
    final rows = await d.rawQuery('''
      SELECT COUNT(*) count, COALESCE(SUM(subtotal),0) total
      FROM transactions WHERE created_at >= ? AND created_at < ?
    ''', [start.toIso8601String(), end.toIso8601String()]);
    return {
      'count': (rows.first['count'] as int?) ?? 0,
      'total': (rows.first['total'] as int?) ?? 0,
    };
  }

  Future<List<Map<String, Object?>>> bestSellers(DateTime day) async {
    final d = await db;
    final start = DateTime(day.year, day.month, day.day);
    final end = start.add(const Duration(days: 1));
    return d.rawQuery('''
      SELECT product_name, SUM(qty) qty, SUM(subtotal) total
      FROM transaction_items ti
      JOIN transactions t ON t.id = ti.transaction_id
      WHERE t.created_at >= ? AND t.created_at < ?
      GROUP BY product_id, product_name
      ORDER BY qty DESC
      LIMIT 10
    ''', [start.toIso8601String(), end.toIso8601String()]);
  }
}
