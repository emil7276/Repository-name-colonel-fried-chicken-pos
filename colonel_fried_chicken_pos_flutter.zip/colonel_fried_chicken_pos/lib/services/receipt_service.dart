import 'dart:typed_data';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../models/cart_item.dart';

class ReceiptService {
  static Future<void> printReceipt({
    required String invoiceNo,
    required DateTime date,
    required List<CartItem> items,
    required int total,
    required int paid,
    required int change,
    required String paymentMethod,
  }) async {
    final doc = pw.Document();
    final money = NumberFormat.currency(
      locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0,
    );
    final bytes = await _build(
      doc, invoiceNo, date, items, total, paid, change, paymentMethod, money,
    );
    await Printing.layoutPdf(onLayout: (_) async => bytes);
  }

  static Future<Uint8List> _build(
    pw.Document doc,
    String invoiceNo,
    DateTime date,
    List<CartItem> items,
    int total,
    int paid,
    int change,
    String paymentMethod,
    NumberFormat money,
  ) async {
    doc.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.roll80,
        margin: const pw.EdgeInsets.all(8),
        build: (context) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.stretch,
          children: [
            pw.Text('COLONEL FRIED CHICKEN',
                textAlign: pw.TextAlign.center,
                style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 12)),
            pw.SizedBox(height: 4),
            pw.Text('INVOICE: $invoiceNo', textAlign: pw.TextAlign.center),
            pw.Text(DateFormat('dd/MM/yyyy HH:mm').format(date),
                textAlign: pw.TextAlign.center),
            pw.Divider(),
            ...items.map((i) => pw.Row(
              children: [
                pw.Expanded(child: pw.Text('${i.product.name} x${i.qty}')),
                pw.Text(money.format(i.subtotal)),
              ],
            )),
            pw.Divider(),
            _line('TOTAL', money.format(total), bold: true),
            _line('BAYAR', money.format(paid)),
            _line('KEMBALI', money.format(change)),
            _line('METODE', paymentMethod),
            pw.SizedBox(height: 10),
            pw.Text('Terima kasih',
                textAlign: pw.TextAlign.center,
                style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
          ],
        ),
      ),
    );
    return doc.save();
  }

  static Future<void> sharePdf({
    required String invoiceNo,
    required DateTime date,
    required List<CartItem> items,
    required int total,
    required int paid,
    required int change,
    required String paymentMethod,
  }) async {
    final doc = pw.Document();
    final money = NumberFormat.currency(
      locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0,
    );
    final bytes = await _build(
      doc, invoiceNo, date, items, total, paid, change, paymentMethod, money,
    );
    await Printing.sharePdf(bytes: bytes, filename: '$invoiceNo.pdf');
  }

  static pw.Widget _line(String a, String b, {bool bold = false}) {
    final style = pw.TextStyle(
      fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal,
    );
    return pw.Row(
      children: [
        pw.Expanded(child: pw.Text(a, style: style)),
        pw.Text(b, style: style),
      ],
    );
  }
}
