class Product {
  final int id;
  final String name;
  final String category;
  final int price;
  final bool active;

  const Product({
    required this.id,
    required this.name,
    required this.category,
    required this.price,
    required this.active,
  });

  factory Product.fromMap(Map<String, Object?> m) => Product(
    id: m['id'] as int,
    name: m['name'] as String,
    category: m['category'] as String,
    price: m['price'] as int,
    active: (m['active'] as int) == 1,
  );
}
