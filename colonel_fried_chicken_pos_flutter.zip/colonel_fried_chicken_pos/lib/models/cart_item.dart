import 'product.dart';

class CartItem {
  final Product product;
  int qty;
  CartItem(this.product, {this.qty = 1});

  int get subtotal => product.price * qty;
}
