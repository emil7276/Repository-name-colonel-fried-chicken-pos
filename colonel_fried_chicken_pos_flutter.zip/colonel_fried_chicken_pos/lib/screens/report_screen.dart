import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../data/app_database.dart';

class ReportScreen extends StatefulWidget {
  const ReportScreen({super.key});
  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  DateTime date = DateTime.now();
  Map<String, Object> summary = {'count': 0, 'total': 0};
  List<Map<String, Object?>> best = [];
  final money = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    summary = await AppDatabase.instance.dailySummary(date);
    best = await AppDatabase.instance.bestSellers(date);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Laporan Penjualan',
            style: TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: ListTile(
                leading: const Icon(Icons.calendar_today),
                title: Text(DateFormat('EEEE, dd MMMM yyyy', 'id_ID').format(date)),
                trailing: IconButton(
                  icon: const Icon(Icons.edit_calendar),
                  onPressed: () async {
                    final picked = await showDatePicker(
                      context: context,
                      initialDate: date,
                      firstDate: DateTime(2020),
                      lastDate: DateTime.now(),
                    );
                    if (picked != null) {
                      date = picked;
                      _load();
                    }
                  },
                ),
              ),
            ),
            Row(children: [
              Expanded(child: _stat('Transaksi', '${summary['count']}', Icons.receipt_long)),
              const SizedBox(width: 10),
              Expanded(child: _stat('Omzet', money.format(summary['total']), Icons.payments)),
            ]),
            const SizedBox(height: 18),
            const Text('Menu Terlaris',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            if (best.isEmpty)
              const Card(child: Padding(
                padding: EdgeInsets.all(20),
                child: Text('Belum ada transaksi pada tanggal ini.'),
              ))
            else
              ...best.asMap().entries.map((e) {
                final r = e.value;
                return Card(
                  child: ListTile(
                    leading: CircleAvatar(child: Text('${e.key + 1}')),
                    title: Text('${r['product_name']}'),
                    subtitle: Text('Terjual ${r['qty']} pcs'),
                    trailing: Text(money.format(r['total'] ?? 0)),
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }

  Widget _stat(String title, String value, IconData icon) => Card(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        Icon(icon, size: 28),
        const SizedBox(height: 6),
        Text(title),
        const SizedBox(height: 4),
        Text(value, textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
      ]),
    ),
  );
}
