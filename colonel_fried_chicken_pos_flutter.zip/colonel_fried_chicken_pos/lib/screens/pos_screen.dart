import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../data/app_database.dart';
import '../models/cart_item.dart';
import '../models/product.dart';
import '../services/receipt_service.dart';
import '../widgets/product_card.dart';

class PosScreen extends StatefulWidget {
  const PosScreen({super.key});
  @override
  State<PosScreen> createState() => _PosScreenState();
}

class _PosScreenState extends State<PosScreen> {
  String category = 'Paket';
  List<Product> products = [];
  final List<CartItem> cart = [];
  final paymentController = TextEditingController();
  String payment = 'Tunai';
  bool loading = true;

  final money = NumberFormat.currency(
    locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0,
  );

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  @override
  void dispose() {
    paymentController.dispose();
    super.dispose();
  }

  Future<void> _loadProducts() async {
    setState(() => loading = true);
    products = await AppDatabase.instance.products(category);
    setState(() => loading = false);
  }

  int get total => cart.fold(0, (sum, e) => sum + e.subtotal);
  int get paid => int.tryParse(paymentController.text.replaceAll('.', '')) ?? 0;
  int get change => paid - total;

  void add(Product p) {
    setState(() {
      final existing = cart.where((e) => e.product.id == p.id);
      if (existing.isNotEmpty) {
        existing.first.qty++;
      } else {
        cart.add(CartItem(p));
      }
    });
  }

  void remove(CartItem item) {
    setState(() {
      if (item.qty > 1) {
        item.qty--;
      } else {
        cart.remove(item);
      }
    });
  }

  Future<void> checkout() async {
    if (cart.isEmpty) return;
    if (payment == 'Tunai' && paid < total) {
      _message('Nominal pembayaran kurang.');
      return;
    }
    final now = DateTime.now();
    final invoice = 'CFC-${DateFormat('yyyyMMdd-HHmmss').format(now)}';
    await AppDatabase.instance.saveTransaction(
      invoiceNo: invoice,
      createdAt: now,
      paymentMethod: payment,
      subtotal: total,
      paid: payment == 'QRIS' ? total : paid,
      changeAmount: payment == 'QRIS' ? 0 : change,
      items: cart.map((i) => <String, Object>{
        'product_id': i.product.id,
        'product_name': i.product.name,
        'qty': i.qty,
        'price': i.product.price,
        'subtotal': i.subtotal,
      }).toList(),
    );

    final snapshot = List<CartItem>.from(cart);
    final snapshotTotal = total;
    final snapshotPaid = payment == 'QRIS' ? total : paid;
    final snapshotChange = payment == 'QRIS' ? 0 : change;
    final snapshotPayment = payment;

    if (!mounted) return;
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Transaksi tersimpan'),
        content: Text('No. $invoice\nTotal: ${money.format(snapshotTotal)}'),
        actions: [
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              await ReceiptService.printReceipt(
                invoiceNo: invoice, date: now, items: snapshot,
                total: snapshotTotal, paid: snapshotPaid,
                change: snapshotChange, paymentMethod: snapshotPayment,
              );
            },
            child: const Text('Cetak / PDF'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
    setState(() {
      cart.clear();
      paymentController.clear();
    });
  }

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Colonel Fried Chicken',
            style: TextStyle(fontWeight: FontWeight.w800)),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
      ),
      body: LayoutBuilder(
        builder: (context, c) {
          final wide = c.maxWidth >= 900;
          if (wide) {
            return Row(children: [
              Expanded(flex: 6, child: _menu()),
              const VerticalDivider(width: 1),
              Expanded(flex: 4, child: _cart()),
            ]);
          }
          return Column(children: [
            Expanded(child: _menu()),
            SizedBox(height: 300, child: _cart()),
          ]);
        },
      ),
    );
  }

  Widget _menu() {
    return Column(
      children: [
        const SizedBox(height: 8),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Row(
            children: ['Paket', 'Satuan', 'Add-on'].map((c) {
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(c),
                  selected: category == c,
                  onSelected: (_) {
                    setState(() => category = c);
                    _loadProducts();
                  },
                ),
              );
            }).toList(),
          ),
        ),
        Expanded(
          child: loading
              ? const Center(child: CircularProgressIndicator())
              : GridView.builder(
                  padding: const EdgeInsets.all(10),
                  gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 190,
                    mainAxisExtent: 150,
                    crossAxisSpacing: 8,
                    mainAxisSpacing: 8,
                  ),
                  itemCount: products.length,
                  itemBuilder: (_, i) => ProductCard(
                    product: products[i], onTap: () => add(products[i]),
                  ),
                ),
        ),
      ],
    );
  }

  Widget _cart() {
    return Container(
      padding: const EdgeInsets.all(12),
      color: Colors.white,
      child: Column(
        children: [
          const Row(children: [
            Icon(Icons.shopping_cart),
            SizedBox(width: 8),
            Text('Pesanan', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ]),
          const Divider(),
          Expanded(
            child: cart.isEmpty
                ? const Center(child: Text('Belum ada item'))
                : ListView.builder(
                    itemCount: cart.length,
                    itemBuilder: (_, i) {
                      final item = cart[i];
                      return ListTile(
                        dense: true,
                        title: Text(item.product.name),
                        subtitle: Text(money.format(item.subtotal)),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(onPressed: () => remove(item), icon: const Icon(Icons.remove_circle_outline)),
                            Text('${item.qty}'),
                            IconButton(onPressed: () => add(item.product), icon: const Icon(Icons.add_circle_outline)),
                          ],
                        ),
                      );
                    },
                  ),
          ),
          const Divider(),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('TOTAL', style: TextStyle(fontWeight: FontWeight.bold)),
              Text(money.format(total),
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            ],
          ),
          const SizedBox(height: 8),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'Tunai', label: Text('Tunai'), icon: Icon(Icons.payments)),
              ButtonSegment(value: 'QRIS', label: Text('QRIS'), icon: Icon(Icons.qr_code_2)),
            ],
            selected: {payment},
            onSelectionChanged: (s) {
              setState(() {
                payment = s.first;
                if (payment == 'QRIS') paymentController.text = total.toString();
              });
            },
          ),
          if (payment == 'Tunai') ...[
            const SizedBox(height: 8),
            TextField(
              controller: paymentController,
              keyboardType: TextInputType.number,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(
                labelText: 'Nominal bayar',
                prefixText: 'Rp ',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 5),
            Align(
              alignment: Alignment.centerRight,
              child: Text('Kembalian: ${money.format(change < 0 ? 0 : change)}'),
            ),
          ],
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: cart.isEmpty ? null : checkout,
              icon: const Icon(Icons.check_circle),
              label: const Text('SIMPAN TRANSAKSI'),
            ),
          ),
        ],
      ),
    );
  }
}
